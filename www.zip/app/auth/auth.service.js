(function () {
    'use strict';

    angular
        .module('auth')
        .service('authService', authService);

    /* @ngInject */
    function authService($http, API_URL, $state, $window, $q, $ionicHistory,HOME) {
        
        var local = {
            destroyCredenciales: destroyCredenciales,
            currentUser:currentUser
        };

        var service = {
            login: login,
            logout: logout,
            autologin: autologin,
            updateRegId: updateRegId,
            register: register,
            updatePassword: updatePassword,
            currentUser: currentUser,
            local: local
        };
        return service;


        function login(usuario){
            var defered = $q.defer();
            var promise = defered.promise;
            $http.post(API_URL+'login', usuario).then(success, error);
            return promise;
            
            function success(p) {
                storeUser(p.data);
                // pushService.register();
                defered.resolve(currentUser());
            }
            function error(error) {
               destroyCredenciales();
                defered.reject(error);
            }
        };

        function autologin() {
            var defered = $q.defer();
            var promise = defered.promise;
            var usuario = currentUser();
            if(usuario){
                 $state.go(HOME);
            }else{
                defered.resolve(false);
            }
            return promise;
        }

        function updateRegId(regid){
            sessionStorage.setItem('regid', regid);
            var usuario_id = JSON.parse(sessionStorage.getItem('usuario')).id;
            return $http.put(API_URL+'/usuarios/'+usuario_id+'/reg_id/'+regid);
        };

        function logout(){
           // var usuario_id = JSON.parse(localStorage.getItem('usuario')).id;
            //return $http.put(API_URL+'/usuarios/'+usuario_id+'/reg_id/undefined').then(function () {
                $window.localStorage.clear();
                $ionicHistory.clearCache();
                 $ionicHistory.clearHistory();
                $state.go('login');
            //});
        };

        function register(usuario){
            return $http.post(API_URL+'login/register', usuario);
        };

        function updatePassword(usuario, contrasenas){
            return $http.post(API_URL+'/usuarios/'+usuario.id+'/change_pass',
                contrasenas,
                {headers:  {'Authorization': 'Bearer '+sessionStorage.getItem('jwt')}}
            );
        };


    function storeUser(usuario) {
            $window.localStorage['usuario'] = JSON.stringify(usuario);
        };
        function currentUser(){
            return JSON.parse(localStorage.getItem('usuario'));
        };
        function destroyCredenciales() {
            $window.localStorage.removeItem('usuario');
        }

    }
})();

